package com.doulk.recharges;

import android.app.*;
import android.os.*;
import android.content.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.content.ClipData;
import android.content.ClipboardManager;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout box;
    EditText search;
    SharedPreferences p;
    int cur = 0;

    String[] seed = new String[]{
        "Sidiki|1590775089;CIM Faso|760258033;Mhd|1374496201;Jean|1360513849;Bado|1556595763;Issaka|838539847;Barro Mangan|1518824597;Tapha Konaté|1575065653;doulkjunior|1446145449;ZouL|1427332787;Yassia ODG|1093014641;Sako De L'or|1363891025;Issouf|1607363765;Kasoume|1600496305;Niga|933656913;Coucou|632059687;Imzo|1023353745;Safking|467579775;Amadou 3e|1572246253;Amidou|1467318405;Marzouk|1671953023",
        "Sidiki|1590775089;CIM Faso|760258033;Mhd|1374496201;Jean|1360513849;Bado|1556595763;Issaka|838539847;Barro Mangan|1518824597;Tapha Konaté|1575065653;doulkjunior|1446145449;ZouL|1427332787;Yassia ODG|1093014641;Sako De L'or|1363891025;Issouf|1607363765;Kasoume|1600496305;Niga|933656913;Coucou|632059687;Imzo|1023353745;Safking|467579775",
        "Doukouré|774835687;Abdou Guira|1641664971;Maïga|1643400273;Nourou|1603811897;RIM'K|1552685455;Amidou Coiff|459504789;Chef Amidou|1647540547;Wendbenedo|1400881443;Dlk Hbdl|1657994201;Tico|1748255951;Dabire|1763603499;Aziz Cissé|1766667405;Sayoré frère de cadré|1743053971;Sayouba tico|1766643181;ZAKARIA MOTO DOCTOR|1772587405;Adama electric|1728654195;DaoudaSouldja|1773642541;Daouda Elec|1778457569;Louba|1499978509;Soum Odg|1778789123;Soum Sankara|1776338423;Salgo Biiga|1782496601;Rasmane odg|1782575693;Issouf wani|1777432471;Boucher|1619238983;Moussa Boucher|1607675335;Seydou Swdg frère krim vrs pharma|1783756029;Ousseni moogo|1786693417;Louky|1781832579;Amael|1784789787;Lamine yéyé|1068841697;Zking|1600741523;PTI moto doctor|1796194809;Yacou Père Soum|1774465453;Derka|1420239477;Around barro|1798236353;Yamal|1789408835"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("doulk", MODE_PRIVATE);
        seed();
        home();
    }

    int dp(int x){ return (int)(x*getResources().getDisplayMetrics().density+0.5f); }

    TextView t(String s,int size,boolean bold){
        TextView v=new TextView(this);
        v.setText(s); v.setTextSize(size); v.setPadding(dp(14),dp(10),dp(14),dp(10));
        if(bold) v.setTypeface(null,1);
        return v;
    }

    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(17); return b;
    }

    void base(String title){
        box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12),dp(12),dp(12),dp(12));
        TextView h=t(title,23,true); h.setGravity(Gravity.CENTER);
        box.addView(h,new LinearLayout.LayoutParams(-1,dp(60)));
        setContentView(box);
    }

    void home(){
        base("DoulK Recharges");
        String[] names={"Client MobCash 1","Client MobCash 2","Client MobCash 3","Crédit"};
        for(int i=0;i<4;i++){
            final int k=i;
            Button b=btn(names[i]);
            b.setOnClickListener(v->{ if(k<3) clients(k); else credits(); });
            box.addView(b,new LinearLayout.LayoutParams(-1,dp(68)));
        }
    }

    void seed(){
        for(int n=0;n<3;n++){
            if(!p.contains("l"+n)){
                ArrayList<String[]> a=new ArrayList<>();
                for(String q:seed[n].split(";")){
                    String[] x=q.split(java.util.regex.Pattern.quote("|"),2);
                    a.add(x);
                }
                save(n,a);
            }
        }
    }

    ArrayList<String[]> get(int n){
        ArrayList<String[]> a=new ArrayList<>();
        String raw=p.getString("l"+n,"");
        if(raw.isEmpty()) return a;
        for(String q:raw.split(";")){
            String[] x=q.split(java.util.regex.Pattern.quote("|"),2);
            if(x.length==2) a.add(x);
        }
        return a;
    }

    void save(int n,ArrayList<String[]> a){
        StringBuilder s=new StringBuilder();
        for(String[] x:a){
            if(s.length()>0)s.append(";");
            s.append(x[0].replace(";"," ")).append("|").append(x[1].replace(";"," "));
        }
        p.edit().putString("l"+n,s.toString()).apply();
    }

    void clients(int n){
        cur=n;
        base("Client MobCash "+(n+1));
        search=new EditText(this); search.setHint("Rechercher nom ou ID");
        box.addView(search,new LinearLayout.LayoutParams(-1,dp(58)));
        Button add=btn("+ Ajouter un client");
        box.addView(add,new LinearLayout.LayoutParams(-1,dp(58)));
        LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(rows); box.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        add.setOnClickListener(v->edit(-1));
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){render(rows);}
            public void afterTextChanged(Editable e){}
        });
        render(rows);
    }

    void render(LinearLayout rows){
        rows.removeAllViews();
        String q=search==null?"":search.getText().toString().toLowerCase(Locale.ROOT);
        ArrayList<String[]> a=get(cur);
        for(int k=0;k<a.size();k++){
            String[] x=a.get(k);
            if(!q.isEmpty() && !x[0].toLowerCase(Locale.ROOT).contains(q) && !x[1].contains(q)) continue;
            final int i=k;
            LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
            TextView v=t(x[0]+"\n"+x[1],17,false);
            r.addView(v,new LinearLayout.LayoutParams(0,dp(70),1));
            Button e=new Button(this); e.setText("Edit");
            e.setOnClickListener(z->edit(i));
            r.addView(e,new LinearLayout.LayoutParams(dp(70),dp(60)));
            Button d=new Button(this); d.setText("Suppr.");
            d.setOnClickListener(z->del(i));
            r.addView(d,new LinearLayout.LayoutParams(dp(78),dp(60)));
            r.setOnClickListener(z->{
                ClipboardManager c=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                c.setPrimaryClip(ClipData.newPlainText("ID",x[1]));
                Toast.makeText(this,"ID copié : "+x[1],Toast.LENGTH_SHORT).show();
            });
            rows.addView(r);
        }
    }

    void edit(int i){
        ArrayList<String[]> a=get(cur);
        LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL);
        EditText n=new EditText(this); n.setHint("Nom");
        EditText id=new EditText(this); id.setHint("ID / numéro"); id.setInputType(2);
        if(i>=0){ n.setText(a.get(i)[0]); id.setText(a.get(i)[1]); }
        f.addView(n); f.addView(id);
        new AlertDialog.Builder(this)
            .setTitle(i<0?"Ajouter un client":"Modifier le client")
            .setView(f).setNegativeButton("Annuler",null)
            .setPositiveButton("Enregistrer",(d,w)->{
                if(n.length()>0 && id.length()>0){
                    if(i<0) a.add(new String[]{n.getText().toString(),id.getText().toString()});
                    else a.set(i,new String[]{n.getText().toString(),id.getText().toString()});
                    save(cur,a); clients(cur);
                }
            }).show();
    }

    void del(int i){
        new AlertDialog.Builder(this).setTitle("Supprimer ?")
            .setMessage("Supprimer ce client ?").setNegativeButton("Annuler",null)
            .setPositiveButton("Supprimer",(d,w)->{
                ArrayList<String[]> a=get(cur); a.remove(i); save(cur,a); clients(cur);
            }).show();
    }

    JSONArray cr(){
        try{return new JSONArray(p.getString("cr","[]"));}catch(Exception e){return new JSONArray();}
    }

    String now(){
        return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.FRANCE).format(new Date());
    }

    void credits(){
        base("Crédit");
        Button add=btn("+ Nouveau crédit"); box.addView(add,new LinearLayout.LayoutParams(-1,dp(62)));
        TextView total=t("",18,true); total.setGravity(Gravity.CENTER); box.addView(total);
        LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(rows); box.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        add.setOnClickListener(v->credit(-1));
        renderCr(rows,total);
    }

    void renderCr(LinearLayout rows,TextView total){
        rows.removeAllViews(); JSONArray j=cr(); double sum=0;
        for(int i=0;i<j.length();i++){
            try{
                JSONObject o=j.getJSONObject(i); sum+=o.optDouble("a");
                final int k=i;
                LinearLayout r=new LinearLayout(this);
                TextView v=t(o.optString("n")+"\n"+o.optString("a")+" FCFA\n"+o.optString("d"),16,false);
                r.addView(v,new LinearLayout.LayoutParams(0,dp(88),1));
                Button e=new Button(this); e.setText("Edit"); e.setOnClickListener(x->credit(k));
                r.addView(e,new LinearLayout.LayoutParams(dp(70),dp(65)));
                Button z=new Button(this); z.setText("Suppr."); z.setOnClickListener(x->{
                    JSONArray q=cr(); q.remove(k); p.edit().putString("cr",q.toString()).apply(); credits();
                });
                r.addView(z,new LinearLayout.LayoutParams(dp(78),dp(65)));
                rows.addView(r);
            }catch(Exception ignored){}
        }
        total.setText("Total crédit : "+String.format(Locale.FRANCE,"%.0f",sum)+" FCFA");
    }

    void credit(int i){
        JSONArray j=cr();
        LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL);
        EditText n=new EditText(this); n.setHint("Nom");
        EditText a=new EditText(this); a.setHint("Montant (FCFA)"); a.setInputType(2);
        if(i>=0) try{JSONObject o=j.getJSONObject(i); n.setText(o.optString("n")); a.setText(o.optString("a"));}catch(Exception ignored){}
        f.addView(n); f.addView(a);
        new AlertDialog.Builder(this).setTitle(i<0?"Nouveau crédit":"Modifier le crédit").setView(f)
            .setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{
                if(n.length()>0 && a.length()>0) try{
                    if(i<0){
                        JSONObject o=new JSONObject(); o.put("n",n.getText().toString()); o.put("a",Double.parseDouble(a.getText().toString())); o.put("d",now()); j.put(o);
                    }else{
                        JSONObject o=j.getJSONObject(i); o.put("n",n.getText().toString()); o.put("a",Double.parseDouble(a.getText().toString()));
                    }
                    p.edit().putString("cr",j.toString()).apply(); credits();
                }catch(Exception ignored){}
            }).show();
    }
}
