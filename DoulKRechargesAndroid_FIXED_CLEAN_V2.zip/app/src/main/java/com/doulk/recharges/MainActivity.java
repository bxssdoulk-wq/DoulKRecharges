package com.doulk.recharges;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private LinearLayout content;
    private int currentList = 1;

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("doulk_data", MODE_PRIVATE);
        home();
    }

    private TextView title(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(22);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(18), dp(12), dp(18));
        return t;
    }

    private Button bigButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(18);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64));
        p.setMargins(dp(12), dp(8), dp(12), dp(8));
        b.setLayoutParams(p);
        return b;
    }

    private LinearLayout base(String titleText) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(10), dp(10), dp(10));

        TextView t = title(titleText);
        root.addView(t);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);

        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        return root;
    }

    private void home() {
        LinearLayout root = base("DoulK Recharges");
        Button b1 = bigButton("Client MobCash 1");
        Button b2 = bigButton("Client MobCash 2");
        Button b3 = bigButton("Client MobCash 3");
        Button bc = bigButton("Credit");

        b1.setOnClickListener(v -> clients(1));
        b2.setOnClickListener(v -> clients(2));
        b3.setOnClickListener(v -> clients(3));
        bc.setOnClickListener(v -> credits());

        content.addView(b1);
        content.addView(b2);
        content.addView(b3);
        content.addView(bc);

        setContentView(root);
    }

    private ArrayList<String[]> getClients(int list) {
        ArrayList<String[]> out = new ArrayList<>();
        String raw = prefs.getString("clients_" + list, "");
        if (raw.isEmpty()) return out;
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new String[]{o.optString("name"), o.optString("id")});
            }
        } catch (JSONException ignored) {
        }
        return out;
    }

    private void saveClients(int list, ArrayList<String[]> data) {
        JSONArray a = new JSONArray();
        for (String[] x : data) {
            JSONObject o = new JSONObject();
            try {
                o.put("name", x[0]);
                o.put("id", x[1]);
                a.put(o);
            } catch (JSONException ignored) {
            }
        }
        prefs.edit().putString("clients_" + list, a.toString()).apply();
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setAllCaps(false);
        return b;
    }

    private void clients(int list) {
        currentList = list;
        LinearLayout root = base("Client MobCash " + list);

        Button back = smallButton("Retour");
        back.setOnClickListener(v -> home());
        content.addView(back);

        Button add = smallButton("Ajouter un client");
        add.setOnClickListener(v -> clientDialog(-1));
        content.addView(add);

        renderClients();

        setContentView(root);
    }

    private void renderClients() {
        if (content == null) return;

        while (content.getChildCount() > 2) {
            content.removeViewAt(2);
        }

        ArrayList<String[]> data = getClients(currentList);

        for (int i = 0; i < data.size(); i++) {
            final int index = i;
            String[] x = data.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6), dp(6), dp(6), dp(6));

            Button copy = smallButton(x[0] + "\n" + x[1]);
            copy.setTextSize(15);
            copy.setOnClickListener(v -> {
                ClipboardManager cm =
                        (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("ID", x[1]));
                Toast.makeText(this, "ID copié", Toast.LENGTH_SHORT).show();
            });

            Button edit = smallButton("Modifier");
            edit.setOnClickListener(v -> clientDialog(index));

            Button del = smallButton("Suppr.");
            del.setOnClickListener(v -> {
                ArrayList<String[]> b = getClients(currentList);
                if (index >= 0 && index < b.size()) {
                    b.remove(index);
                    saveClients(currentList, b);
                    renderClients();
                }
            });

            row.addView(copy, new LinearLayout.LayoutParams(0, dp(64), 1));
            row.addView(edit, new LinearLayout.LayoutParams(dp(90), dp(64)));
            row.addView(del, new LinearLayout.LayoutParams(dp(70), dp(64)));
            content.addView(row);
        }
    }

    private void clientDialog(int index) {
        ArrayList<String[]> data = getClients(currentList);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), dp(10));

        EditText name = new EditText(this);
        name.setHint("Nom");
        EditText id = new EditText(this);
        id.setHint("ID / numéro");
        id.setInputType(InputType.TYPE_CLASS_PHONE);

        if (index >= 0 && index < data.size()) {
            name.setText(data.get(index)[0]);
            id.setText(data.get(index)[1]);
        }

        box.addView(name);
        box.addView(id);

        new AlertDialog.Builder(this)
                .setTitle(index < 0 ? "Ajouter" : "Modifier")
                .setView(box)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Enregistrer", (d, w) -> {
                    String n = name.getText().toString().trim();
                    String number = id.getText().toString().trim();
                    if (n.isEmpty()) n = "Client";
                    if (index < 0) {
                        data.add(new String[]{n, number});
                    } else if (index < data.size()) {
                        data.set(index, new String[]{n, number});
                    }
                    saveClients(currentList, data);
                    renderClients();
                })
                .show();
    }

    private ArrayList<JSONObject> getCredits() {
        ArrayList<JSONObject> out = new ArrayList<>();
        String raw = prefs.getString("credits", "");
        if (raw.isEmpty()) return out;
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                out.add(a.getJSONObject(i));
            }
        } catch (JSONException ignored) {
        }
        return out;
    }

    private void saveCredits(ArrayList<JSONObject> data) {
        JSONArray a = new JSONArray();
        for (JSONObject o : data) a.put(o);
        prefs.edit().putString("credits", a.toString()).apply();
    }

    private void credits() {
        LinearLayout root = base("Credit");

        Button back = smallButton("Retour");
        back.setOnClickListener(v -> home());
        content.addView(back);

        Button add = smallButton("Ajouter un crédit");
        add.setOnClickListener(v -> creditDialog(-1));
        content.addView(add);

        renderCredits();

        setContentView(root);
    }

    private void renderCredits() {
        while (content.getChildCount() > 2) {
            content.removeViewAt(2);
        }

        ArrayList<JSONObject> data = getCredits();

        for (int i = 0; i < data.size(); i++) {
            final int index = i;
            JSONObject o = data.get(i);

            String date = o.optString("date");
            String name = o.optString("name");
            String amount = o.optString("amount");

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(8), dp(8), dp(8), dp(8));

            TextView info = new TextView(this);
            info.setText(date + "\n" + name + " - " + amount + " FCFA");
            info.setTextSize(16);

            LinearLayout buttons = new LinearLayout(this);
            buttons.setOrientation(LinearLayout.HORIZONTAL);

            Button edit = smallButton("Modifier");
            edit.setOnClickListener(v -> creditDialog(index));

            Button del = smallButton("Suppr.");
            del.setOnClickListener(v -> {
                ArrayList<JSONObject> b = getCredits();
                if (index >= 0 && index < b.size()) {
                    b.remove(index);
                    saveCredits(b);
                    renderCredits();
                }
            });

            buttons.addView(edit, new LinearLayout.LayoutParams(0, dp(55), 1));
            buttons.addView(del, new LinearLayout.LayoutParams(0, dp(55), 1));

            row.addView(info);
            row.addView(buttons);
            content.addView(row);
        }
    }

    private void creditDialog(int index) {
        ArrayList<JSONObject> data = getCredits();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), dp(10));

        EditText name = new EditText(this);
        name.setHint("Nom");

        EditText amount = new EditText(this);
        amount.setHint("Montant");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);

        if (index >= 0 && index < data.size()) {
            JSONObject old = data.get(index);
            name.setText(old.optString("name"));
            amount.setText(old.optString("amount"));
        }

        box.addView(name);
        box.addView(amount);

        new AlertDialog.Builder(this)
                .setTitle(index < 0 ? "Nouveau crédit" : "Modifier le crédit")
                .setView(box)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Enregistrer", (d, w) -> {
                    String n = name.getText().toString().trim();
                    String a = amount.getText().toString().trim();

                    try {
                        JSONObject o;
                        if (index < 0) {
                            o = new JSONObject();
                            o.put("date", new SimpleDateFormat(
                                    "dd/MM/yyyy HH:mm", Locale.getDefault())
                                    .format(new Date()));
                            data.add(o);
                        } else {
                            o = data.get(index);
                        }

                        o.put("name", n);
                        o.put("amount", a);
                        saveCredits(data);
                        renderCredits();
                    } catch (JSONException ignored) {
                    }
                })
                .show();
    }
}
