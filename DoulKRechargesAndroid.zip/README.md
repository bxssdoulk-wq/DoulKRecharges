# Doul’K Recharges
Projet Android avec 3 listes MobCash, copie rapide des IDs et registre Crédit.
Aucun identifiant ou mot de passe de caisse n'est inclus.
