package com.doulk.recharges;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    LinearLayout root, content;
    android.content.SharedPreferences prefs;
    int currentList = 0;
    final String[] titles = {"Client MobCash 1","Client MobCash 2","Client MobCash 3"};
    final String[] seed = {
        "Sidiki|ID1;CIM Faso|ID2;Mhd|ID3;Jean|ID4;Bado|ID5;Issaka|ID6;Barro Mangan|ID7;Tapha Konaté|ID8;doulkjunior|ID9;ZouL|ID10;Yassia ODG|ID11;Sako de L'or|ID12;Issouf|ID13;Kasoume|ID14;Niga|ID15;Coucou|ID16;Imzo|ID17;Safking|ID18;Amadou 3e|ID19;Amidou|ID20;Marzouk|ID21",
        "Sidiki|ID1;CIM Faso|ID2;Mhd|ID3;Jean|ID4;Bado|ID5;Issaka|ID6;Barro Mangan|ID7;Tapha Konaté|ID8;doulkjunior|ID9;ZouL|ID10;Yassia ODG|ID11;Sako de L'or|ID12;Issouf|ID13;Kasoume|ID14;Niga|ID15;Coucou|ID16;Imzo|ID17;Safking|ID18;Amadou 3e|ID19;Amidou|ID20;Marzouk|ID21",
        "Sidiki|ID1;CIM Faso|ID2;Mhd|ID3;Jean|ID4;Bado|ID5;Issaka|ID6;Barro Mangan|ID7;Tapha Konaté|ID8;doulkjunior|ID9;ZouL|ID10;Yassia ODG|ID11;Sako de L'or|ID12;Issouf|ID13;Kasoume|ID14;Niga|ID15;Coucou|ID16;Imzo|ID17;Safking|ID18;Amadou 3e|ID19;Amidou|ID20;Marzouk|ID21"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("data", MODE_PRIVATE);
        seedIfNeeded();
        home();
    }

    void seedIfNeeded() {
        for (int i=0;i<3;i++) if (!prefs.contains("list"+i)) prefs.edit().putString("list"+i, seed[i]).apply();
    }

    int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density + .5f); }
    Button btn(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(17); return b; }
    TextView tv(String s,int size) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(dp(12),dp(10),dp(12),dp(10)); return t; }

    void setup(String title) {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(10),dp(10),dp(10),dp(10));
        TextView h=tv(title,24); h.setGravity(Gravity.CENTER); root.addView(h,new LinearLayout.LayoutParams(-1,dp(60)));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    void home() {
        setup("DoulK Recharges");
        for(int i=0;i<3;i++){ final int x=i; Button b=btn(titles[i]); b.setOnClickListener(v->clients(x)); content.addView(b,new LinearLayout.LayoutParams(-1,dp(65))); }
        Button c=btn("Credit"); c.setOnClickListener(v->credits()); content.addView(c,new LinearLayout.LayoutParams(-1,dp(65)));
    }

    ArrayList<String[]> get(int list) {
        ArrayList<String[]> a=new ArrayList<>();
        String s=prefs.getString("list"+list,"");
        if(!s.isEmpty()) for(String q:s.split(";")) {
            String[] x=q.split(Pattern.quote("|"),2);
            if(x.length==2) a.add(x);
        }
        return a;
    }

    void save(int list, ArrayList<String[]> a) {
        StringBuilder s=new StringBuilder();
        for(String[] x:a){ if(s.length()>0)s.append(";"); s.append(x[0].replace(";","")).append("|").append(x[1].replace(";","")); }
        prefs.edit().putString("list"+list,s.toString()).apply();
    }

    void clients(int list) {
        currentList=list; setup(titles[list]);
        Button add=btn("+ Ajouter un client"); add.setOnClickListener(v->editClient(-1)); content.addView(add,new LinearLayout.LayoutParams(-1,dp(60)));
        EditText search=new EditText(this); search.setHint("Rechercher"); search.setSingleLine(true); content.addView(search);
        LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL); content.addView(rows);
        Runnable render=()->{
            rows.removeAllViews(); String q=search.getText().toString().toLowerCase(Locale.ROOT);
            ArrayList<String[]> a=get(currentList);
            for(int k=0;k<a.size();k++){ String[] x=a.get(k); if(!q.isEmpty() && !x[0].toLowerCase(Locale.ROOT).contains(q) && !x[1].contains(q)) continue;
                final int i=k;
                LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
                TextView v=tv(x[0]+"\n"+x[1],17); r.addView(v,new LinearLayout.LayoutParams(0,dp(70),1));
                Button e=btn("Modifier"); e.setTextSize(11); e.setOnClickListener(z->editClient(i)); r.addView(e,new LinearLayout.LayoutParams(dp(75),dp(60)));
                Button d=btn("Suppr."); d.setTextSize(11); d.setOnClickListener(z->{ArrayList<String[]> b=get(currentList); b.remove(i); save(currentList,b); render.run();}); r.addView(d,new LinearLayout.LayoutParams(dp(70),dp(60)));
                r.setOnClickListener(z->{ android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(android.content.ClipData.newPlainText("ID",x[1])); Toast.makeText(this,"ID copié : "+x[1],Toast.LENGTH_SHORT).show(); });
                rows.addView(r);
            }
        };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){render.run();} public void afterTextChanged(android.text.Editable e){}});
        render.run();
        Button back=btn("Retour"); back.setOnClickListener(v->home()); content.addView(back);
    }

    void editClient(int idx) {
        ArrayList<String[]> a=get(currentList);
        LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL);
        EditText n=new EditText(this); n.setHint("Nom");
        EditText id=new EditText(this); id.setHint("ID / numéro"); id.setInputType(InputType.TYPE_CLASS_PHONE);
        if(idx>=0){n.setText(a.get(idx)[0]); id.setText(a.get(idx)[1]);}
        f.addView(n); f.addView(id);
        new AlertDialog.Builder(this).setTitle(idx<0?"Ajouter un client":"Modifier le client").setView(f)
            .setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{
                if(n.length()>0 && id.length()>0){ if(idx<0)a.add(new String[]{n.getText().toString(),id.getText().toString()}); else a.set(idx,new String[]{n.getText().toString(),id.getText().toString()}); save(currentList,a); clients(currentList); }
            }).show();
    }

    String now(){return new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date());}

    void credits() {
        setup("Crédit");
        Button add=btn("+ Nouveau crédit"); add.setOnClickListener(v->credit(-1)); content.addView(add,new LinearLayout.LayoutParams(-1,dp(60)));
        LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL); content.addView(rows);
        renderCredits(rows);
        Button back=btn("Retour"); back.setOnClickListener(v->home()); content.addView(back);
    }

    ArrayList<String> creditsData(){ return new ArrayList<>(Arrays.asList(prefs.getString("credits","").split("\\n",-1))); }

    void renderCredits(LinearLayout rows) {
        rows.removeAllViews(); double total=0;
        ArrayList<String> a=creditsData();
        for(int i=0;i<a.size();i++){ if(a.get(i).trim().isEmpty())continue; String[] p=a.get(i).split(Pattern.quote("|"),4); if(p.length<4)continue;
            try{total+=Double.parseDouble(p[2]);}catch(Exception ignored){}
            final int k=i; LinearLayout r=new LinearLayout(this);
            TextView v=tv(p[1]+"\n"+p[2]+" FCFA\n"+p[3],16); r.addView(v,new LinearLayout.LayoutParams(0,dp(95),1));
            Button e=btn("Modifier"); e.setTextSize(10); e.setOnClickListener(x->credit(k)); r.addView(e,new LinearLayout.LayoutParams(dp(75),dp(60)));
            Button d=btn("Suppr."); d.setTextSize(10); d.setOnClickListener(x->{ArrayList<String> z=creditsData(); if(k<z.size())z.remove(k); prefs.edit().putString("credits",String.join("\n",z)).apply(); credits();}); r.addView(d,new LinearLayout.LayoutParams(dp(70),dp(60)));
            rows.addView(r);
        }
        TextView sum=tv("Total crédit : "+String.format(Locale.getDefault(),"%.0f",total)+" FCFA",18); sum.setGravity(Gravity.CENTER); rows.addView(sum,0);
    }

    void credit(int idx) {
        ArrayList<String> a=creditsData(); String date=now(), name="", amount="";
        if(idx>=0 && idx<a.size()){String[] p=a.get(idx).split(Pattern.quote("|"),4); if(p.length>=4){date=p[0];name=p[1];amount=p[2];}}
        LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL);
        TextView dt=tv("Date et heure : "+date,16); EditText n=new EditText(this); n.setHint("Nom"); EditText am=new EditText(this); am.setHint("Montant FCFA"); am.setInputType(InputType.TYPE_CLASS_NUMBER);
        n.setText(name); am.setText(amount); f.addView(dt); f.addView(n); f.addView(am);
        final String fixedDate=date;
        new AlertDialog.Builder(this).setTitle(idx<0?"Nouveau crédit":"Modifier le crédit").setView(f).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{
            if(n.length()>0 && am.length()>0){String line=fixedDate+"|"+n.getText().toString().replace("|","")+"|"+am.getText().toString().replace("|","")+"|Crédit"; if(idx<0)a.add(line); else if(idx<a.size())a.set(idx,line); prefs.edit().putString("credits",String.join("\n",a)).apply(); credits();}
        }).show();
    }
}
